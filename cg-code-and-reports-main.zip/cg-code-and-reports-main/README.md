# cg-code-and-reports

https://youtube.be/NPcnymtP2SE   refer to execute

using "code blocks" software
